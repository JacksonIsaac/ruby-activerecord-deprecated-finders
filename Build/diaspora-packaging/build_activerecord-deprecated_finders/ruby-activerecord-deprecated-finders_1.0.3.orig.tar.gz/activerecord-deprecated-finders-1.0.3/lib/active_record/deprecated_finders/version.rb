module ActiveRecord
  module DeprecatedFinders
    VERSION = "1.0.3"
  end
end
